package py.edu.uaa.pooj.operadores;

public class BucleInfinito {

	// PRACTICA
	public void bucleInfinito() {		
		
		boolean obvioQueSep = true;
		while (obvioQueSep == true) {
			  System.out.println("Estudiar mucho para el primer parcial!!!");		
			  //obvioQueSep = false;
		}
		//TODO "Crear un bucle infinito que muestre un mensaje 
		//en consola diciendo "Estudiar mucho para el primer parcial ;)"					
	}
	
	public static void main(String[] args) {
		
		BucleInfinito bucleEstudiar = new BucleInfinito();
		
		bucleEstudiar.bucleInfinito();
		
	}
	
	//changes made by Andrew Salinas :)
}
