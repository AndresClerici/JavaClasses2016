package py.edu.uaa.pooj.operadores.test;

public class OperacionesMatematicas {

	// PRACTICA - 
	public int encontrarMinimo(int[] numeros) {		
		int min = numeros[1];
		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] < min) 
				min = numeros[i];
		}
		// TODO "Encontrar el valor minimo de un array de enteros"
		return min;
	}

	// PRACTICA
	public int encontrarMaximo(int[] numeros) {
		int max = numeros[1];
		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] > max) 
				max = numeros[i];
		}
		// TODO "Encontrar el valor minimo de un array de enteros"
		return max;
	}

	// PRACTICA	
	//No me funciono de esta forma1 retornar un array, no se bien por que
	/*public int[] filtrarImpares(int[] numeros) {
		int c = 0;
		int impares[] = new int[c];
		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] % 3 == 0)					
				impares[c++] = numeros[i];			
		}		
		// TODO
		// "En base a un array de enteros recibidos como parametros, filtrar solamente los numeros impares"		
		return impares;
	}*/
	
	public int filtrarImpares(int[] numeros) {
		int impares = 0;		
		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] % 2 != 0) {				
				impares = numeros[i];
				System.out.println(impares);
			} else { // le tuve que poner un else por que o si no me repetia los valores impares, no se por que
				impares = 0;
			}
		}		
		// TODO
		// "En base a un array de enteros recibidos como parametros, filtrar solamente los numeros impares"
		return 0;
	}
	
	public static void main(String[] args) {
		//Se crea un objeto de la clase en este caso OperacionesMatematicas
		OperacionesMatematicas testOpMat = new OperacionesMatematicas();
		
		//Se crea un array de enteros
		int[] numeroMenor  = { 10, 20, 30, 40, 50 };
		int[] numeroMaximo = { 10, 20, 30, 40, 50 };
		int[] numeroImpar  = { 9, 20, 27,  40, 47};

		System.out.println(testOpMat.encontrarMinimo(numeroMenor));
		System.out.println(testOpMat.encontrarMaximo(numeroMaximo));
		testOpMat.filtrarImpares(numeroImpar);
		//System.out.println(testOpMat.filtrarImpares(numeroImpar)); aqu� fue el problema, no pude solucionar el error forma1
	}
	
	//changes made by Andrew Salinas
}
