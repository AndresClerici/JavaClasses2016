package py.edu.uaa.pooj.actividad1;

public class PersonaJuridica {
	private String razonSocial;

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

}
